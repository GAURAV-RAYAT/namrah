$(window).on("load", function () {
    $(".loading").fadeOut("slow");
  });
  
  // Popup Varibales and Retractor
  let successGreen = "#7af87a";
  let errorRed = "#BA0000";
  let successIc = '<i class="fas fa-thumbs-up fa-2x"></i>';
  let errorIc = '<i class="fas fa-exclamation-circle fa-2x"></i>';
  
  $("#popup__close").click(() => {
    gsap.to(".popup_card", {
      y: "150%",
      duration: 0.3,
    });
  });
  
  function retract() {
    setTimeout(() => {
      gsap.to(".popup_card", {
        y: "150%",
        duration: 0.3,
      });
    }, 3000);
  }
  function pop(info, color, icon) {
    $(".popup_card .popup__text").html(info);
    $(".popup_card").css({ "background-color": color });
    $("#popup__close").html(icon);
    gsap.to(".popup_card", {
      y: "0%",
      duration: 0.3,
    });
  }
  // Popup Varibales and Retractor
  
  // Nav Bar Hamburger
  $(".ham").click(function () {
    $("#items_cover").addClass("active-nav");
    $("#items").addClass("active-nav");
  });
  $(".close_ham").click(function () {
    $("#items").removeClass("active-nav");
    $("#items_cover").removeClass("active-nav");
  });
  
  $("#items_cover").click(function () {
    $("#items").removeClass("active-nav");
    $("#items_cover").removeClass("active-nav");
  });
  // Nav Bar Hamburger
  
  // Device Pickup Form
  let loc = {
    buildNo: null,
    address1: null,
    address2: null,
    contactno: null,
    pincode: null,
  };
  $("#pickup-form").submit(function (e) {
    if ($(this).children().find("input").val().length <= 0) {
      e.preventDefault();
      pop("<p>Please fill the required fields</p>", errorRed);
      retract();
    } else {
      e.preventDefault();
      loc["buildNo"] = $(this).children().find("input[name='buildNo']").val();
      loc["address1"] = $(this).children().find("input[name='address1']").val();
      loc["address2"] = $(this).children().find("input[name='address2']").val();
      loc["contactno"] = $(this).children().find("input[name='contact']").val();
      loc["pincode"] = $(this).children().find("input[name='pincode']").val();
  
      gsap.to(".conf", {
        display: "flex",
        opacity: 1,
        duration: 0.3,
      });
      gsap.to(".conf__wrapper", {
        delay: 0.3,
        y: "0%",
        duration: 0.3,
      });
    }
  });
  
  $("#conf__close").click(function () {
    gsap.to(".conf__wrapper", {
      delay: 0.3,
      y: "-200%",
      duration: 0.3,
    });
    gsap.to(".conf", {
      opacity: 0,
      display: "none",
      duration: 0.3,
    });
  });
  
  // Repair
  $(".brands").click(function () {
    let brand = $(this).attr("data-brand");
    window.location.replace("/repair/" + brand);
  });
  
  $("#repair-pickup-form").submit(function (e) {
    e.preventDefault();
    $(".place_order").text("Cooking...");
    let device = $(this)
      .children()
      .find("select[name='brand'] option:selected")
      .val();
    let model = $(this).children().find("input[name='device_name']").val();
    $.ajax({
      type: "POST",
      url: "/repair/",
      data: {
        action: "saveOrder",
        device_name: device + " " + model,
        address1: $(this).children().find("input[name='address1']").val(),
        address2: $(this).children().find("input[name='address2']").val(),
        contact: $(this).children().find("input[name='contactno']").val(),
        pincode: $(this).children().find("input[name='pincode']").val(),
        csrfmiddlewaretoken: $("input[name=csrfmiddlewaretoken]").val(),
      },
      success: function () {
        gsap.to(".done", {
          display: "flex",
        });
        gsap.to(".done_wrap", {
          delay: 0.2,
          scale: 1,
          duration: 0.3,
        });
      },
      error: function () {
        $(".place_order").text("Place Order");
        gsap.to(".failed", {
          display: "flex",
        });
        gsap.to(".failed_wrap", {
          delay: 0.2,
          scale: 1,
          duration: 0.3,
        });
      },
    });
  });
  
  // Repair
  
  // Approval Page
  $("#approval-form").submit(function (e) {
    e.preventDefault();
    $("#approve_button").text("Processing..");
    $.ajax({
      type: "POST",
      url: "/approval/" + $(this).attr("data-orderId"),
      data: {
        customer_name: $("input[name='name']").val(),
        price: $("input[name='price']").val(),
        desc: $("textarea[name='desc']").val(),
        csrfmiddlewaretoken: $("input[name=csrfmiddlewaretoken]").val(),
      },
      success: function (r) {
        $("#approve_button").text("Data Processed");
        window.location.replace("/md-admin/");
      },
      error: function () {
        $("#approve_button").text("Something went wrong!!");
      },
    });
  });
  // Approval Page
  
  // Status Changer
  $("#status-changer").change(function () {
    let current_status = $(this).find(":selected").val();
    console.log(current_status);
    $.ajax({
      type: "POST",
      url: "/md-admin/",
      data: {
        id: $(this).attr("data-id"),
        status: current_status,
        csrfmiddlewaretoken: $("input[name=csrfmiddlewaretoken]").val(),
      },
      success: function () {
        window.location.reload();
      },
      error: function () {
        console.error("Try Again!");
      },
    });
  });
  // Status Changer
  
  // Admin
  $(".order").click(function () {
    let id = $(this).attr("data-orderId");
    $(".togglearrow" + id).toggleClass("active-arrow");
    $(".tog" + id).slideToggle("fast");
  });
  $(".order").click(function () {
    let id = $(this).attr("data-orderId");
    $(".rtogglearrow" + id).toggleClass("active-arrow");
    $(".rtog" + id).slideToggle("fast");
  });
  
  $("#refreshList").click(function () {
    window.location.reload();
  });
  
  $("input[name='orderId']").keyup(function () {
    let id = $(this).val();
    let orderList = $(".order");
    for (let i = 0; i < orderList.length; i++) {
      const element = orderList[i];
      let orderId = $(element).attr("data-orderId");
      $(".rtogglearrow" + orderId).removeClass("active-arrow");
      $(".rtog" + orderId).slideUp("fast");
    }
    if (id.length == 0) {
      for (let i = 0; i < orderList.length; i++) {
        const element = orderList[i];
        $(element).css({ display: "flex" });
      }
    } else {
      for (let i = 0; i < orderList.length; i++) {
        const e = orderList[i];
        if ($(e).attr("data-orderId") != id) {
          $(e).css({ display: "none" });
        } else {
          if ($(e).css("display") == "none") {
            $(e).css({ display: "flex" });
          } else {
          }
        }
      }
    }
  });
  // Admin
  
  // Login
  $("#login-form").submit(function (event) {
    event.preventDefault();
    $("#loginbtn").text("Loging In...");
    $.ajax({
      type: "POST",
      url: "/login/",
      data: {
        username: $("input[name='username']").val(),
        password: $("input[name='password']").val(),
        csrfmiddlewaretoken: $("input[name=csrfmiddlewaretoken]").val(),
      },
      success: function (response) {
        if (response == false) {
          $("#loginbtn").text("Login");
          $("input[name='username']").css({ "border-color": errorRed });
          $("input[name='password']").css({ "border-color": errorRed });
          $(".errors").html("<p>Uh Oh! That didn't work</p>");
          $("#login-form").trigger("reset");
        } else {
          console.log("Logined");
          window.location.replace("/");
        }
      },
      error: function () {
        console.error("Login Failed");
      },
    });
  });
  $("#login-form input").keyup(function () {
    $(".errors").empty();
  });
  // Login
  
  // Sign Up
  $("#signup-form").submit(function (e) {
    e.preventDefault();
    let pass1 = $(".passfld").val();
    let pass2 = $(".pass2fld").val();
    if (pass1 != pass2) {
      $(".errors").html("<p>Password does not match!</p>");
    } else {
      $("#signup").text("Signing Up...");
      $.ajax({
        type: "POST",
        url: "/register/",
        data: {
          name: $(this).children().find("input[name='name']").val(),
          email: $(this).children().find("input[name='email']").val(),
          username: $(this).children().find("input[name='username']").val(),
          password1: $(this).children().find("input[name='password1']").val(),
          password2: $(this).children().find("input[name='password2']").val(),
          csrfmiddlewaretoken: $("input[name=csrfmiddlewaretoken]").val(),
        },
        success: function (response) {
          window.location.replace(response);
        },
        error: function () {
          console.log("login failed");
        },
      });
    }
  });
  $(".passfld").keyup(function () {
    $(".errors").empty();
  });
  $(".pass2fld").keyup(function () {
    $(".errors").empty();
  });
  // Sign Up
  
  // Cancel Booking
  $(".cancel_booking").click(function () {
    $.ajax({
      type: "POST",
      url: "/orders/",
      data: {
        orderId: $(this).attr("data-orderId"),
        csrfmiddlewaretoken: $("input[name=csrfmiddlewaretoken]").val(),
      },
      success: function () {
        window.location.reload();
      },
      error: function () {
        console.log("Something went wrong!");
      },
    });
  });
  // Cancel Booking
  // Animation
  $(window).on("load", function () {
    gsap
      .to(".info_card", {
        x: "0%",
        duration: 0.6,
      })
      .then(
        setTimeout(function () {
          gsap.to(".info_card", {
            x: "110%",
            duration: 0.6,
          });
        }, 4000)
      );
  
    gsap
      .from(".left__image__wrapper", {
        width: 200,
        height: 200,
        ease: Power1.easeOut,
        duration: 1,
      })
      .then(
        gsap.from(".main_home_logo", {
          width: "0rem",
          ease: Power1.easeOut,
          duration: 1,
        })
      )
      .then(
        gsap.to(".description_text", {
          y: "0%",
          delay: 0.6,
          ease: Power1.easeOut,
          duration: 0.6,
        })
      );
    pop_icons(iconList);
  });
  
  let iconList = $(".icon");
  
  function pop_icons(iconList) {
    gsap
      .to(iconList, {
        y: "-20px",
        stagger: 0.4,
        duration: 0.5,
      })
      .then(
        gsap.to(iconList, {
          y: "0px",
          delay: 0.4,
          stagger: 0.3,
          duration: 0.5,
        })
      );
  }
  
  setInterval(function () {
    pop_icons(iconList);
  }, 4000);
  // Animation